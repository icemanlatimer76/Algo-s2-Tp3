public class Piece
{
   private static int   cptInstance;
   private String       forme;
   private String       couleur;
   private int          taille;
   private int          numInstance; 

   public String toString()
   {
      return "(" + numInstance +"/" + Piece.cptInstance +") [" + forme + " : " + couleur + " (" + taille +" cm) ]";
   }


   public Piece()
   {
      instance();
   }

   public Piece(String forme, String couleur, int taille)
   {
      this.forme   =  forme;
      this.couleur =  couleur;
      this.taille  =  taille;
      instance();

   }

   private void instance()
   {
      Piece.cptInstance++;
      this.numInstance = Piece.cptInstance;
   }
} 