public class TestUtil
{
   public static void main(String[] a)
   {
      
      System.out.println ( Util.min ( 12, 4 ) );
      System.out.println ( Util.max ( 12, 4 ) );
   }
} 