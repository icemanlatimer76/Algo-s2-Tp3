public class Piece
{
   private String forme;
   private String couleur;
   private int    taille;

   public String toString()
   {
      return "[" + forme + " : " + couleur + " (" + taille +" cm) ]";
   }
/*
   public Piece()
   {


   }
*/
   public Piece(String forme, String couleur, int taille)
   {
      this.forme   =  forme;
      this.couleur =  couleur;
      this.taille  =  taille;

   }
} 