public class Test6
{
   public static void main (String[] arg)
   {

      Piece p1 = new Piece();
      System.out.println ( p1.toString() );
      System.out.println ( p1 );
      
   }
}